La tabla verdosa

La arqueóloga Xantel Jones ha sido llevada a un lugar secreto lleno de peligros por unas personas muy malas.
Le han dicho que si quiere salir de hay para regresar a su vida cotidiana dando clases en la Universidad, necesita encontrar los 9 fragmentos de una tabla.
Y si no lo hace, le haran cosas muy malas.

Tú misión, ayudar a Xantel a conseguir todas las piezas de la tabla, para poder salir, por donde entró, con vida.
Tendrás que recoger llaves para poder abrir las puertas que te bloquean el paso, para poder continuar con tu misión.
Pasa por la puertas para ir de un lugar del recinto a otro.
Y ten cuidado con los animalitos que hay por el recinto, y sobre todo con los pinchitos mortíferos.
Una vez conseguidas las 9 piezas de la tabla, regresa al punto exacto en donde apareciste y pasa a través de esa puerta. Los malos habrán conseguido lo que querían, y Xantel la ansiada libertad.


Controles
Puedes jugar con teclado, Joystick Sinclair o Joystick Kempston.

Con teclado
Q : Salta
A : Pasar por las puertas/portales.
O : Izquierda
P : Derecha
SPACE + O ó SPACE + P: Desplaza las cajas que se puedan mover.


Juego está hecho para ZX Spectrum 48k con el motor MTE MK1.

